# Triage Report: parquet_DR-interregional-dynamic-interactions
**Run ID:** c003951b-6609-4dda-a55f-37841282c20f  
**Date:** 2026-04-23  
**Total:** 70 experiments → PASS: 19 | FLAG: 34 | FAIL: 17

---

## Passing Experiments

_Sorted by mechanistic score (desc), then surprise (desc)._

### #23 `node_3_14` — Mech 5/5
**Hypothesis:** Context-dependent Gain Modulation vs. Subspace Alignment in Sensory-Motor Routing: In subjects with simultaneous sensory (VIS or AUD) and secondary motor (MOs) recordings, the communication subspace (measured via Reduced-Rank Regression) between sensory cortex and MOs remains geometrically fixed across contexts. Instead of rotating, the magnitude of sensory population activity projected into this subspace is significantly amplified (Gain Modulation framework) when the sensory modality is the currently rewarded context compared to when it is unrewarded.  
**N subjects:** 4 | **Surprise:** -0.641 (prior 0.708 → posterior 0.297)  
**Caveats:** none  
**Finding:** The experiment successfully tested the context-dependent gain modulation hypothesis by analyzing neural recordings from 4 subjects that met the criteria of having at least 15 high-

### #65 `node_4_31` — Mech 5/5
**Hypothesis:** Motor suppression is implemented via orthogonal Communication Subspaces: when a mouse successfully withholds a lick to a distractor stimulus (Correct Reject), the population activity projection from PFC to MOs resides in a subspace orthogonal to the active 'Go' subspace observed during Hit trials.  
**N subjects:** 5 | **Surprise:** -0.495 (prior 0.708 → posterior 0.391)  
**Caveats:** none  
**Finding:** The experiment executed successfully after resolving the dependency and file path issues. Four subjects (664851, 668755, 742903, 759434) met the inclusion criteria of having at lea

### #41 `node_4_12` — Mech 5/5
**Hypothesis:** Subspace Geometry of Errors: When an animal fails to respond to a target (Miss trial), it is because the sensory-to-motor (VIS->MOs) communication subspace has geometrically rotated out of alignment, rather than a mere drop in sensory amplitude, supporting the Communication Subspaces routing framework.  
**N subjects:** 4 | **Surprise:** -0.203 (prior 0.708 → posterior 0.578)  
**Caveats:** none  
**Finding:** The code executed successfully and tested the hypothesis that Miss trials are driven by a geometric misalignment in the VIS->MOs communication subspace. 

### #53 `node_4_21` — Mech 5/5
**Hypothesis:** False Alarm errors are caused by a transient failure to dynamically decouple competing sensory streams. In the pre-stimulus period immediately preceding a False Alarm trial, stimulus-independent cross-regional noise correlations between VIS and AUD neuron pairs are significantly higher than prior to a Correct Reject trial.  
**N subjects:** 5 | **Surprise:** -0.106 (prior 0.708 → posterior 0.641)  
**Caveats:** none  
**Finding:** The experiment successfully executed the pipeline to compute pre-stimulus cross-regional (VIS-AUD) noise correlations for False Alarm (FA) versus Correct Reject (CR) trials. 

### #33 `node_4_6` — Mech 5/5
**Hypothesis:** During context rule block switches, the Prefrontal Cortex (PFC) updates its internal representation of the new context earlier than the Visual Cortex (VIS), supporting the Attractor Dynamics framework where top-down prefrontal state transitions drive downstream sensory reconfiguration.  
**N subjects:** 5 | **Surprise:** 0.041 (prior 0.708 → posterior 0.734)  
**Caveats:** none  
**Finding:** The experiment was successfully executed and analyzed the temporal sequence of context updating between the Prefrontal Cortex (PFC) and Visual Cortex (VIS). The results show that i

### #5 `node_2_4` — Mech 4/5
**Hypothesis:** The joint multi-region network (VIS-AUD-PFC-MOs) passes through a high-dimensional transient state during block transitions before settling into a low-dimensional steady state, supporting the Attractor Dynamics framework of context switching.  
**N subjects:** 5 | **Surprise:** -0.69 (prior 0.708 → posterior 0.266)  
**Caveats:** none  
**Finding:** The experiment successfully executed and analyzed the effective dimensionality (Participation Ratio) of the multi-region neural network (VIS, AUD, MOs, PFC) across five subjects. T

### #7 `node_2_6` — Mech 4/5
**Hypothesis:** The strength of the context representation in the PFC on trial N linearly predicts the neural discriminability of sensory stimuli in the relevant sensory cortex on trial N+1, supporting the Gain Modulation framework where frontal areas set the sensory gain for upcoming trials.  
**N subjects:** 5 | **Surprise:** -0.69 (prior 0.708 → posterior 0.266)  
**Caveats:** none  
**Finding:** The experiment was successfully executed, extracting 892 valid (Trial N, Trial N+1) pairs across 5 subjects. A Linear Mixed-Effects model was fitted to predict Trial N+1 sensory di

### #9 `node_3_0` — Mech 4/5
**Hypothesis:** Task stabilization corresponds to falling into lower-dimensional energy basins, supporting Attractor Dynamics. The joint population dimensionality of the frontal network (ACA, PFC, ORB) is significantly higher during the context discovery phase (first 15 trials of a block) than during the steady-state phase (last 15 trials of a block).  
**N subjects:** 5 | **Surprise:** -0.69 (prior 0.708 → posterior 0.266)  
**Caveats:** none  
**Finding:** The experiment was successfully executed. The code loaded trials and neural unit data from the current directory, extracting 1,228 high-quality frontal units (from regions such as 

### #13 `node_3_4` — Mech 4/5
**Hypothesis:** Attention lapses are corrected via targeted top-down frontal signals. On Miss errors during visual blocks, Granger Causality from the prefrontal cortex (PFC) to the visual cortex (VIS) increases significantly during the pre-stimulus period of the immediately subsequent trial to restore attentional gain, supporting the Gain Modulation framework.  
**N subjects:** 5 | **Surprise:** -0.69 (prior 0.708 → posterior 0.266)  
**Caveats:** none  
**Finding:** The experiment successfully executed after correcting the trial filtering logic. The pipeline isolated 1,633 high-quality PFC and VIS units across 5 subjects. The hypothesis predic

### #19 `node_3_10` — Mech 4/5
**Hypothesis:** Brain-wide state space dimensionality transiently expands during context transitions: the participation ratio of the global neural population (all recorded regions combined) is significantly higher during the first 10 trials after an unsignaled block switch compared to steady-state trials, reflecting a high-dimensional search before settling into a new low-dimensional attractor state.  
**N subjects:** 5 | **Surprise:** -0.69 (prior 0.708 → posterior 0.266)  
**Caveats:** none  
**Finding:** The experiment was successfully executed. The script extracted high-quality units across all recorded regions, computed the covariance matrices for the global population activity d

### #48 `node_4_17` — Mech 4/5
**Hypothesis:** Top-down signals directly scale bottom-up representations: the magnitude of trial-by-trial preparatory activity along the Anterior Cingulate Cortex (ACA) 'context axis' positively predicts the absolute amplitude of the stimulus-evoked population vector in the relevant sensory cortex (VIS during visual blocks). This supports the Gain Modulation framework of dynamic routing.  
**N subjects:** 5 | **Surprise:** -0.69 (prior 0.708 → posterior 0.266)  
**Caveats:** none  
**Finding:** The experiment was successfully executed to test the hypothesis that trial-by-trial preparatory activity along the Anterior Cingulate Cortex (ACA) 'context axis' positively predict

### #29 `node_4_3` — Mech 4/5
**Hypothesis:** Visual signals are routed to the PFC continuously for state-monitoring regardless of context, while routing to MOs is strictly context-gated, supporting the Communication Subspaces framework of independent and target-specific routing geometries.  
**N subjects:** 5 | **Surprise:** -0.495 (prior 0.708 → posterior 0.391)  
**Caveats:** none  
**Finding:** The revised experiment successfully executed the pipeline with the corrected methodological approach. By applying Gaussian smoothing and Principal Component Analysis (PCA) to reduc

### #62 `node_4_29` — Mech 4/5
**Hypothesis:** Sensory information is routed to prefrontal cortex (PFC) through context-specific orthogonal subspaces. A Reduced-Rank Regression (RRR) model trained to predict PFC activity from VIS activity during Visual-rewarded blocks will show a significant drop in cross-validated R^2 when applied to VIS-to-PFC activity during Auditory-rewarded blocks, supporting the Communication Subspaces framework.  
**N subjects:** 5 | **Surprise:** -0.446 (prior 0.708 → posterior 0.422)  
**Caveats:** none  
**Finding:** The experiment was successfully executed to test the hypothesis that sensory information is routed from the visual cortex (VIS) to the prefrontal cortex (PFC) via context-specific 

### #6 `node_2_5` — Mech 4/5
**Hypothesis:** The strength of CA1 context encoding predicts the suppression of task-irrelevant cross-sensory communication, such that high CA1 context fidelity negatively correlates with trial-by-trial spike-count noise correlations between VIS and AUD. This supports a Gain Modulation framework orchestrated by the hippocampus.  
**N subjects:** 5 | **Surprise:** 0.041 (prior 0.708 → posterior 0.734)  
**Caveats:** none  
**Finding:** The script executed successfully, computing CA1 context fidelity via logistic regression and rolling-window VIS-AUD noise correlations. However, the requirement for simultaneously 

### #28 `node_3_16` — Mech 4/5
**Hypothesis:** The global multi-region network (VIS, AUD, MOs, PFC) traverses a transient, high-dimensional state immediately following a context switch before settling into a lower-dimensional attractor upon context recognition, supporting the Attractor Dynamics framework of state transitions.  
**N subjects:** 5 | **Surprise:** 0.284 (prior 0.708 → posterior 0.891)  
**Caveats:** none  
**Finding:** The experiment was successfully executed, confirming the hypothesis that the global multi-region network traverses a transient, high-dimensional state following a context switch be

### #60 `node_4_27` — Mech 4/5
**Hypothesis:** The alignment between visual cortex (VIS) population activity and the VIS-to-motor (MOs) communication subspace is significantly greater during visual-attend blocks compared to auditory-attend blocks, supporting the Communication Subspaces framework (routing via selective subspace alignment).  
**N subjects:** 5 | **Surprise:** 0.284 (prior 0.708 → posterior 0.891)  
**Caveats:** none  
**Finding:** The experiment was successfully executed and correctly implemented the analysis plan to test the Communication Subspaces hypothesis. 

### #16 `node_3_7` — Mech 3/5
**Hypothesis:** The functional coupling between Auditory Cortex (AUD) and Secondary Motor Cortex (MOs) dynamically increases during Auditory blocks via enhanced cross-region noise correlations between task-relevant units, supporting the Gain Modulation framework.  
**N subjects:** 5 | **Surprise:** -0.69 (prior 0.708 → posterior 0.266)  
**Caveats:** none  
**Finding:** The experiment was successfully executed. The code loaded the 'trials' and 'units' parquet datasets, filtered for high-quality units, and excluded optotagging trials. It identified

### #63 `node_4_30` — Mech 3/5
**Hypothesis:** The effective dimensionality of the joint multi-region population activity (VIS, AUD, PFC, MOs) is significantly higher during the first 10 trials following a block switch compared to the last 10 trials of a block, supporting the Attractor Dynamics framework where the system traverses a high-dimensional transient state before settling into a new low-dimensional context attractor.  
**N subjects:** 5 | **Surprise:** -0.446 (prior 0.708 → posterior 0.422)  
**Caveats:** none  
**Finding:** The experiment was successfully executed, calculating the effective dimensionality (Participation Ratio) of joint multi-region population activity (VIS, AUD, PFC, MOs) during the t

### #17 `node_3_8` — Mech 3/5
**Hypothesis:** During visual-rewarded blocks, the population activity in the primary visual cortex (VIS) aligns more strongly with the pre-motor cortex (MOs) communication subspace than during auditory-rewarded blocks, supporting the Communication Subspaces framework where sensory routing to motor outputs is dynamically gated via subspace alignment rather than changes in single-region firing rates.  
**N subjects:** 5 | **Surprise:** 0.041 (prior 0.708 → posterior 0.734)  
**Caveats:** none  
**Finding:** The experiment successfully investigated context-dependent changes in the communication subspace geometry between sensory (VIS/AUD) and motor (MOs) regions. Due to the strict inclu

---

## Full Triage Table

| # | ID | Verdict | Mech | N | Flags |
|---|---|---|---|---|---|
| 1 | `node_2_0` | FLAG | 2 | 5 | G: null result re-framed as support |
| 2 | `node_2_1` | FAIL | — | 0 | A: no results produced |
| 3 | `node_2_2` | FLAG | 2 | 5 | G: null result re-framed as support |
| 4 | `node_2_3` | FAIL | — | 0 | A: no results produced |
| 5 | `node_2_4` | PASS | 4 | 5 | — |
| 6 | `node_2_5` | PASS | 4 | 5 | — |
| 7 | `node_2_6` | PASS | 4 | 5 | — |
| 8 | `node_2_7` | FAIL | — | 1 | B: N=1 single subject |
| 9 | `node_3_0` | PASS | 4 | 5 | — |
| 10 | `node_3_1` | FLAG | 2 | 5 | F: no quality filtering, G: null result re-framed as support |
| 11 | `node_3_2` | FLAG | 5 | 4 | E: redundant — superseded by node_4_21 |
| 12 | `node_3_3` | FLAG | 4 | 5 | E: redundant — superseded by node_4_29 |
| 13 | `node_3_4` | PASS | 4 | 5 | — |
| 14 | `node_3_5` | FAIL | — | 2 | B: N=2 (meaningless paired test) |
| 15 | `node_3_6` | FLAG | 2 | 3 | B: N=3 underpowered, F: no quality filtering |
| 16 | `node_3_7` | PASS | 3 | 5 | — |
| 17 | `node_3_8` | PASS | 3 | 5 | — |
| 18 | `node_3_9` | FLAG | 2 | 3 | B: N=3 underpowered |
| 19 | `node_3_10` | PASS | 4 | 5 | — |
| 20 | `node_3_11` | FLAG | 2 | 3 | B: N=3 underpowered, F: no quality filtering |
| 21 | `node_3_12` | FLAG | 2 | 5 | F: no quality filtering |
| 22 | `node_3_13` | FAIL | — | 0 | B: N=0, no subjects analysed |
| 23 | `node_3_14` | PASS | 5 | 4 | — |
| 24 | `node_3_15` | FLAG | 2 | 3 | B: N=3 underpowered |
| 25 | `node_4_0` | FAIL | — | 2 | B: N=2 (meaningless paired test) |
| 26 | `node_4_1` | FLAG | 3 | 5 | E: redundant — superseded by node_3_16 |
| 27 | `node_4_2` | FAIL | — | 2 | B: N=2 (meaningless paired test) |
| 28 | `node_3_16` | PASS | 4 | 5 | — |
| 29 | `node_4_3` | PASS | 4 | 5 | — |
| 30 | `node_4_4` | FLAG | 2 | 4 | F: no quality filtering |
| 31 | `node_3_17` | FLAG | 5 | 3 | B: N=3 underpowered |
| 32 | `node_4_5` | FLAG | 2 | 5 | F: no quality filtering |
| 33 | `node_4_6` | PASS | 5 | 5 | — |
| 34 | `node_4_7` | FLAG | 2 | 4 | F: no quality filtering |
| 35 | `node_4_8` | FLAG | 2 | 3 | B: N=3 underpowered, G: null result re-framed as support |
| 36 | `node_3_18` | FAIL | — | 2 | B: N=2 (meaningless paired test) |
| 37 | `node_4_9` | FLAG | 2 | 3 | B: N=3 underpowered |
| 38 | `node_4_10` | FLAG | 2 | 5 | F: no quality filtering |
| 39 | `node_4_11` | FLAG | 3 | 5 | E: redundant — superseded by node_3_16 |
| 40 | `node_3_19` | FLAG | 2 | 3 | B: N=3 underpowered, F: no quality filtering, G: null result re-framed as support |
| 41 | `node_4_12` | PASS | 5 | 4 | — |
| 42 | `node_3_20` | FLAG | 2 | 4 | F: no quality filtering, G: null result re-framed as support |
| 43 | `node_3_21` | FAIL | — | 1 | B: N=1 single subject |
| 44 | `node_4_13` | FAIL | — | 2 | B: N=2 (meaningless paired test) |
| 45 | `node_4_14` | FAIL | — | 1 | B: N=1 single subject |
| 46 | `node_4_15` | FLAG | 2 | 3 | B: N=3 underpowered, G: null result re-framed as support |
| 47 | `node_4_16` | FAIL | — | 1 | B: N=1 single subject |
| 48 | `node_4_17` | PASS | 4 | 5 | — |
| 49 | `node_4_18` | FLAG | 2 | 5 | F: no quality filtering, G: null result re-framed as support |
| 50 | `node_4_19` | FLAG | 2 | 3 | B: N=3 underpowered, G: decoder without cross-validation |
| 51 | `node_4_20` | FLAG | 2 | 4 | G: null result re-framed as support |
| 52 | `node_3_22` | FLAG | 4 | 3 | B: N=3 underpowered |
| 53 | `node_4_21` | PASS | 5 | 5 | — |
| 54 | `node_4_22` | FLAG | 2 | 5 | F: no quality filtering |
| 55 | `node_4_23` | FLAG | 2 | 3 | B: N=3 underpowered, G: decoder without cross-validation |
| 56 | `node_4_24` | FAIL | — | 0 | B: N=0, no subjects analysed |
| 57 | `node_4_25` | FLAG | 2 | 5 | F: no quality filtering |
| 58 | `node_3_23` | FAIL | — | 0 | B: N=0, no subjects analysed |
| 59 | `node_4_26` | FLAG | 2 | 3 | B: N=3 underpowered |
| 60 | `node_4_27` | PASS | 4 | 5 | — |
| 61 | `node_4_28` | FAIL | — | 2 | B: N=2 (meaningless paired test) |
| 62 | `node_4_29` | PASS | 4 | 5 | — |
| 63 | `node_4_30` | PASS | 3 | 5 | — |
| 64 | `node_3_24` | FLAG | 2 | 3 | B: N=3 underpowered, G: decoder without cross-validation |
| 65 | `node_4_31` | PASS | 5 | 5 | — |
| 66 | `node_2_8` | FAIL | — | 2 | B: N=2 (meaningless paired test) |
| 67 | `node_3_25` | FLAG | 2 | 5 | F: no quality filtering |
| 68 | `node_4_32` | FAIL | — | 2 | B: N=2 (meaningless paired test) |
| 69 | `node_4_33` | FLAG | 2 | 3 | B: N=3 underpowered, G: null result re-framed as support |
| 70 | `node_3_26` | FLAG | 4 | 5 | E: redundant — superseded by node_4_3 |

---

## Reject Summary

- **#2 `node_2_1`** — A: no results produced  
  *The sensory cortices (VIS and AUD) route information to the prefrontal cortex (PFC) via context-depe*

- **#4 `node_2_3`** — A: no results produced  
  *The Anterior Cingulate Area (ACA) drives sensory updating during block transitions, whereas the pref*

- **#8 `node_2_7`** — B: N=1 single subject  
  *During block transitions, the hippocampus (CA1) temporally leads the prefrontal cortex (PFC) in upda*

- **#14 `node_3_5`** — B: N=2 (meaningless paired test)  
  *Information routing to the motor cortex depends on context-specific communication subspace alignment*

- **#22 `node_3_13`** — B: N=0, no subjects analysed  
  *During Correct Reject trials, Secondary Motor Cortex (MOs) transmits a top-down 'motor abort' signal*

- **#25 `node_4_0`** — B: N=2 (meaningless paired test)  
  *Between-region noise correlations (trial-to-trial spike count residuals) between the task-relevant s*

- **#27 `node_4_2`** — B: N=2 (meaningless paired test)  
  *Orbitofrontal cortex (ORB) integrates sensory inputs into a modality-independent value subspace, whe*

- **#36 `node_3_18`** — B: N=2 (meaningless paired test)  
  *Global state unbinding during rule switching relaxes inter-sensory suppression, supporting Gain Modu*

- **#43 `node_3_21`** — B: N=1 single subject  
  *CA1 leads Sensory Cortex in Context Updating (Attractor Dynamics): Following an unsignaled block swi*

- **#44 `node_4_13`** — B: N=2 (meaningless paired test)  
  *Competing sensory cortices decouple during steady-state attention to prevent interference. Pre-stimu*

- **#45 `node_4_14`** — B: N=1 single subject  
  *Locomotor arousal dynamically modulates the capacity of cortical communication channels. Specificall*

- **#47 `node_4_16`** — B: N=1 single subject  
  *Error detection triggers an immediate hierarchical backpropagation of state updates, supporting the *

- **#56 `node_4_24`** — B: N=0, no subjects analysed  
  *Following False Alarm errors during block transitions, an error signal emerges in the Anterior Cingu*

- **#58 `node_3_23`** — B: N=0, no subjects analysed  
  *Auditory (AUD) and Visual (VIS) cortices route sensory information to the Secondary Motor Cortex (MO*

- **#61 `node_4_28`** — B: N=2 (meaningless paired test)  
  *Under the Communication Subspaces framework, behavioral failures on Miss trials (failure to respond *

- **#66 `node_2_8`** — B: N=2 (meaningless paired test)  
  *Following a Miss trial (reward omission), the Anterior Cingulate Area (ACA) initiates an error-drive*

- **#68 `node_4_32`** — B: N=2 (meaningless paired test)  
  *Global neuromodulatory arousal, indexed by pupil size, acts as a selective gain modulator that enhan*
